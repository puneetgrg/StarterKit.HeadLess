define("epi-find/content/ContentController", [
    "dojo/_base/declare",

    "../_ControllerBase",
    "./OverviewModel",
    "./ExploreModel",
    "../widget/Contents",
    "../widget/_ActionableMixin"
],
function(declare,
    _ControllerBase,
    OverviewModel, ExploreModel, ContentsWidget, _ActionableMixin
) {
    return declare([_ControllerBase, _ActionableMixin], {
        // summary:
        //      Controller for Overview views.

        overviewModel: null,
        exploreModel: null,
        widget: null,

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this.inherited(arguments);

            this.overviewModel = new OverviewModel();
            this.overviewModel.init();

            this.exploreModel = new ExploreModel();
            this.exploreModel.init();

            this.widget = new ContentsWidget({
                overviewModel: this.overviewModel,
                exploreModel: this.exploreModel
            });

            this.own(this.widget);
        },

        takeAction: function(actions, params) {
            this.widget.takeAction(actions, params);
            this.currentAction = this.widget.currentAction;
            return this.widget;
        },

        show: function() {
            this._setupView([this.widget]);
        }
    });
});