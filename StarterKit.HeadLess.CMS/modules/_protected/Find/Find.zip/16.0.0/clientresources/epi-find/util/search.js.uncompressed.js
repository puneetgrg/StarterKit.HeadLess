define("epi-find/util/search", [], function() {
    // module:
    //		epi-find/util/search

    var search = {
        // summary:
        //		This module utility methods that can be used when executing Elastic Search queries.

        escapeQueryStringQuery: function(value, skipEscapingWildcard) {
            // summary:
            //     Escapes characters that have a special meaning in a querystring query.


            // Also see QueryEscaping in the EPiServer.Find .NET API

            // From http://www.elasticsearch.org/guide/en/elasticsearch/reference/current/query-dsl-query-string-query.html#_reserved_characters:
            // The reserved characters are: + - && || ! ( ) { } [ ] ^ " ~ * ? : \ /
            //
            // We already had the semicolon in our list and it is unclear if escaping it actually serves a purpose.
            var specialCharactersSkipWildcardRegex = /(\+|\-|\&\&|\|\||\!|\(|\)|\{|\}|\[|\]|\^|\~|\?|\:|\\|\/|\;)/g;
            var specialCharactersRegex             = /(\+|\-|\&\&|\|\||\!|\(|\)|\{|\}|\[|\]|\^|\~|\*|\?|\:|\\|\/|\;)/g;
            var quotesRegex = /(")/g;
            var evenNumberOfQuotes = /^(([^"]*"){2})*[^"]*$/;

            var escaped = value.replace(skipEscapingWildcard ? specialCharactersSkipWildcardRegex : specialCharactersRegex, "\\$1");
            if(!evenNumberOfQuotes.test(escaped))
            {
                escaped = escaped.replace(quotesRegex, "\\$1");
            }

            return escaped;
        }

    };

    return search;
});
