﻿define("epi-find/servicehealth/ServiceHealthModel", [
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/Stateful",
    "dijit/Destroyable"
],
function (
    declare,
    config,
    lang,
    when,
    Stateful,
    Destroyable
    ) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Service Health model.
        store: null,
        url: null,

        postscript: function() {
            this.inherited(arguments);
            if (!this.store) {
                this.store = config.dependencies["epi-find.ServiceHealthStore"];
            }
        },

        init: function () {
        },

        load: function () {
            var servicehealthQuery = this.store.query();

            when(servicehealthQuery.data, lang.hitch(this, function (data) {
                this.set("url", data.baseUrl + "?token=" + data.token);
            }), lang.hitch(this, function (error) {
                this.set("url", "");
            }));
        }
    });
});
