---
id: changelog
title: Changelog
---

All notable changes to this project will be documented in this file. See CONTRIBUTING.md for commit guidelines.

### [0.0.5](#v0.0.5) (2021-08-03)


### Features

* Sync newly defined badge and button token values ([df960c8](https://github.com/optimizely/repos/axiom/commits/df960c8b3247c7a8db4bc442c4e9d6153062fa9e))

### [0.0.4](#v0.0.4) (2021-07-07)


### Features

* Add definition for "Semi-Bold" font weight (600) ([aedfde6](https://github.com/optimizely/repos/axiom/commits/aedfde6949df3749f658afc02ee262247d43393e))
* Change body font size to 14px and use rem values for font sizes ([0f415e3](https://github.com/optimizely/repos/axiom/commits/0f415e394073d8247ebd135646c4db5c74610765))

### [0.0.3](#v0.0.3) (2021-06-11)


### Features

* Sync color tokens ([28566fa](https://github.com/optimizely/repos/axiom/commits/28566fa620d025d9439402d080cd56722252ebbc))
* Sync typography header line heights ([122d081](https://github.com/optimizely/repos/axiom/commits/122d08126272053212eb9841de3af1a778aac5d8))
* Update typography sizes to fit in 8 pixel grid ([e4fa304](https://github.com/optimizely/repos/axiom/commits/e4fa30470a215ec7e319359ad6f0fc068187e899))

### [0.0.2](#v0.0.2) (2021-05-07)


### Features

* Add brand logos with text and in white ([4afef9d](https://github.com/optimizely/repos/axiom/commits/4afef9dfb511670afec817de99b0bdf93d3a0dbb))
* Add favicon to brand assets ([54887aa](https://github.com/optimizely/repos/axiom/commits/54887aaff55d10edc4991a358a226ca4fcb78fb3))
* Add Inter font files ([ca5dfb1](https://github.com/optimizely/repos/axiom/commits/ca5dfb1a2e25cd3b18ae9fb2b8f0eb3352e2a406))
* Add login background image ([a17b304](https://github.com/optimizely/repos/axiom/commits/a17b30437702caa5ac8922bebec023e21a92142b))
* Add optimizely brand logo in svg ([a911475](https://github.com/optimizely/repos/axiom/commits/a91147554a708ac7f7f9743d61358bfac494624a))
* Initial release of color and typography tokens
