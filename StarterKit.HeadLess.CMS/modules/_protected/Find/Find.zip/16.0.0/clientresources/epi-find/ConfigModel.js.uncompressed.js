define("epi-find/ConfigModel", [
    "dojo/_base/declare",
    "dojo/_base/config",

    "dojo/Deferred",
    "dojo/Stateful",
    "dojo/topic",

    "epi-saas-base/RetryableXhrWrapper",
    "dojo/i18n!./nls/ConfigModel"
],
    function(declare, config,
             Deferred, Stateful,
             topic, RetryableXhrWrapper,
             i18n) {

        // module:
        //      epi-find/ConfigModel

        var Model = declare([Stateful], {
            // summary:
            //     Model for the application configuration.

            // xhrHandler: object
            //      An XHR implementation to use when reading configuration
            xhrHandler: null,

            //  config: object
            //      An object representing application configuration
            config: null,

            //  target: string
            //      Url to the configuration endpoint
            target: null,

            constructor: function(options) {
                declare.safeMixin(this, options);
                this.xhrHandler = this.xhrHandler || new RetryableXhrWrapper();
            },

            refresh: function() {
                // summary:
                //      Updates the model with configuration values from server side.
                //  tags:
                //      public
                if (!this.target) {
                    throw new Error("The 'target' property is not set.");
                }

                var self = this;

                return this.xhrHandler.xhrGet({
                    url: this.target,
                    handleAs: "json"
                }).then(function(result) {
                    self.set("config", result.item);
                    return result.item;
                }, function(error) {
                    var notification = {topic: "global", key: "ReadConfig"};
                    notification.type = "error";
                    notification.message = i18n.configErrorMessage;
                    notification.details = error;
                    topic.publish("epi/notification", notification);
                });
            },

            getValue: function(/*String*/ path) {
                var pathParts = path.split("."),
                    currentConfigPath = this.config;
                for (var i=0; i< pathParts.length; i++) {
                    if (currentConfigPath !== null && currentConfigPath !== undefined) {
                        currentConfigPath = currentConfigPath[pathParts[i]];
                    }
                    else {
                        break;
                    }
                }
                return currentConfigPath;
            }
        });
        var configModel = new Model();
        return configModel;
    });
