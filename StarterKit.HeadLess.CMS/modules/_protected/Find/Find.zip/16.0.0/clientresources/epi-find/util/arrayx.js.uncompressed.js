define("epi-find/util/arrayx", [
    "dojo/_base/array"
], function(
    array
) {
    // module:
    //		epi-find/util/arrayx

    var arrayExtensions = {
        // summary:
        //		This module provides utility methods to process and compare arrays.

        intersected: function(/*Array|Object*/ array1, /*Array|Object*/ array2, /*Boolean?*/ caseSensitive, /*Boolean?*/ honorWhitespaces) {
            // summary:
            //     Checks whether two specified arrays intersect.
            // array1:
            //		First array or object to compare.
            // array2:
            //		Second array or object to compare.
            // caseSensitive:
            //		Indicates whether comparison should be case sensitive.
            // honorWhitespaces:
            //		Indicates whether whitespaces should be honored and not ignored when comparing string entities.
            // tags:
            //		public
            // example:
            // |    var array1 = [1, 2], array2 = [2, false];
            // |	var intersected = arrayx.intersected(array1, array2); // should return true.
            // example:
            // |    var foo = " hello  ", array = ["Hello", 10, true];
            // |	var intersected = arrayx.intersected(foo, array); // should return true.

            if (!array1 || !array2) {
                return false;
            }

            var prepare = function (value) {
                if (value === null || value === undefined) {
                    return null;
                }
                if (typeof value === "string") {
                    if (!value) {
                        return null;
                    }
                    if (!caseSensitive) {
                        value = value.toLowerCase();
                    }
                    if (!honorWhitespaces) {
                        value = value.trim();
                    }
                }
                return value;
            };

            array1 = array.map(this.ensureArray(array1), prepare);
            array2 = array.map(this.ensureArray(array2), prepare);

            return array.some(array1, function (phraseItem) {
                if (phraseItem === null || phraseItem === undefined) {
                    return false;
                }
                return array.some(array2, function (synonymItem) {
                    if (synonymItem === null || synonymItem === undefined) {
                        return false;
                    }
                    return synonymItem === phraseItem;
                });
            });
        },

        parse: function (/*String*/ value, /*String*/ separator, /*Boolean?*/ keepWhitespaces, /*Boolean?*/ keepEmptyEntries) {
            // summary:
            //     Parses String value into array using specified separator.
            // value:
            //		Value to parse.
            // keepWhitespaces:
            //		Indicates whether whitespaces should not be trimmed.
            // keepEmptyEntries:
            //		Indicates whether null or undefined entities should be included in resulting array.
            // tags:
            //		public
            // example:
            // |    var value = "first,second   , ,,";
            // |	var parsedArray = arrayx.parse(value, ","); // should return ["first", "second"].
            // example:
            // |    var value = "first,second, whitespaces here ,,";
            // |	var parsedArray = arrayx.parse(value, ",", true); // should return ["first", "second", " whitespaces here "].
            // example:
            // |    var value = 100;
            // |	var parsedArray = arrayx.parse(value, ","); // should return [100].

            if (typeof value !== "string") {
                return this.ensureArray(value);
            }

            var result = value.split(separator);

            if (!keepWhitespaces) {
                result = array.map(result, function (item) {
                    return item.trim();
                });
            }

            if (!keepEmptyEntries) {
                result = array.filter(result, function (item) {
                    return !!item;
                });
            }

            return result;
        },

        ensureArray: function (value) {
            // summary:
            //     Returns original value if it is array or creates array with specified value as an entry.
            // value:
            //		Value that should be "represented" as an array.
            // tags:
            //		public
            // example:
            // |    var value = [1, 2];
            // |	var result = arrayx.ensureArray(value); // should return original [1, 2].
            // example:
            // |    var value = "some text";
            // |	var result = arrayx.ensureArray(value); // should return ["some text"].
            // example:
            // |    var value = null;
            // |	var result = arrayx.ensureArray(value); // should return empty array [].

            if (value === null || value === undefined) {
                return [];
            }
            return value instanceof Array ? value : [value];
        }
    };

    return arrayExtensions;
});