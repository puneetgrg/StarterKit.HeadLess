﻿define("epi-find/manage/DashboardModel", [
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/Stateful",
    "dijit/Destroyable"
],
function (
    declare,
    config,
    Stateful,
    Destroyable
    ) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Statistics model.

        topQueryStore: null,
        queryStore: null,
        topHitStore: null,
        nullQueryStore: null,

        constructor: function () {
            this.queryStore = config.dependencies["epi-find.QueryStore"];
            this.topQueryStore = config.dependencies["epi-find.TopQueryStore"];
            this.topHitStore = config.dependencies["epi-find.TopHitStore"];
            this.nullQueryStore = config.dependencies["epi-find.NullQueryStore"];
        },

        init: function () {
        }
    });
});
