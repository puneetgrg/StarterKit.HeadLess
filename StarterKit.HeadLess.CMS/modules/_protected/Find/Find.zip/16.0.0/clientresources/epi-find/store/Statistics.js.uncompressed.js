﻿define("epi-find/store/Statistics", [
        "dojo/_base/declare",
        "dojo/_base/lang",
        "./ResourceStore"
],
function (declare,
          lang,
          ResourceStore) {
    // No base class, but for purposes of documentation, the base class is dojo/store/api/Store

    return declare(ResourceStore, {
        // summary:
        //		This is a basic store for RESTful communicating with Statistics.
        //		It implements dojo/store/api/Store.

        constructor: function (options) {
            this.idProperty = "query";
            this.listProperty = "hits";
            declare.safeMixin(this, options);
        },

        _getList: function(data, options) {
            var result = this.inherited(arguments);
            if (options && result instanceof Array) {
                return result.slice(options.start, options.count);
            }
            return result;
        },

        _getTotal: function(total) {
            return this.inherited(arguments).then(function(total) {
                if(total > 100) { // since we cannot page stats in the backed we stop att a 100
                    return 100;
                }
                return total;
            });
        },

        query: function (query, options) {
            var newQuery = lang.clone(query || {}),
                newOptions = lang.clone(options || {});
            if (newQuery.previousQuery) { // TODO: Consider removing this transform and use q_previous
                newQuery["query.previous"] = newQuery.previousQuery;
                delete newQuery.previousQuery;
            }
            var start = 0;
            if (newOptions && newOptions.start) {
                start = newOptions.start;
                newQuery.start = start;
            }
            delete newOptions.start;
            if (newOptions && newOptions.count) {
                newQuery.size = newOptions.count;
            delete newOptions.count;
            }
            var results = this.inherited(arguments, [newQuery, newOptions]);
            return results;
        }
    });

});