define("epi-find/AccessModel", [
    "dojo/_base/array",
    "dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "./ConfigModel",
    "./Intents!"
],
    function(array,
             config,
             declare,
             lang,
             ConfigModel
        ) {

        // module:
        //      epi-find/AccessModel

        var AccessItem = declare(null, {
            // summary:
            //      Represents a single access item

            intent: null,
            allowedOptions: null,
            enabledOptions: null,
            allowedRoles: null,
            enabledRoles: null,

            constructor: function(options) {
                declare.safeMixin(this, options);

                this.allowedOptions = this.allowedOptions || {};
                this.enabledOptions = this.enabledOptions || {};

                this.allowedRoles = this.allowedRoles || [];
                this.enabledRoles = this.enabledRoles || [];
            },

            enableFor: function() {
                // summary:
                //      This method change enabledOptions or enabledRoles depending on parameter type.
                //      It can accept multiple arguments.
                // example:
                //      access.view.synonyms.enableFor({admin:true}, ["Admin", "SearchAdmin"]);
                for (var i=0; i<arguments.length; i++) {
                    var param = arguments[i];
                    if (typeof param === "string" || param instanceof String) {
                        this.enabledRoles.push(param);
                    }
                    else if (param instanceof Array) {
                        this.enabledRoles = this.enabledRoles.concat(param);
                    }
                    else if (param instanceof Object) {
                        lang.mixin(this.enabledOptions, param);
                    }

                }
            },

            allowFor: function() {
                // summary:
                //      This method change allowedOptions or allowedRoles depending on parameter type.
                //      It can accept multiple arguments.
                // example:
                //      access.view.synonyms.allowFor({admin:true}, ["Admin", "SearchAdmin"]);
                for (var i=0; i<arguments.length; i++) {
                    var param = arguments[i];
                    if (param instanceof Object) {
                        lang.mixin(this.allowedOptions, param);
                    }
                    else if (param instanceof String) {
                        this.allowedRoles.push(param);
                    }
                    else if (param instanceof Array) {
                        this.allowedRoles = this.allowedRoles.concat(param);
                    }
                }
            },
            isEnabled: function() {
                return this._isMatch(this.enabledOptions, this.enabledRoles);
            },
            isAllowed: function() {
                return this._isMatch(this.allowedOptions, this.allowedRoles);
            },

            _isMatch: function(options, roles) {
                if(ConfigModel.config === null) {
                    throw new Error("Config is not loaded yet. Access model can not be used.");
                }

                // Check options first
                if (options) {
                    for (var option in options) {
                        if (options[option] !== ConfigModel.config[option]) {
                            return false;
                        }
                    }
                }

                // Check roles if access options fulfilled
                if (roles && roles.length && ConfigModel.config.roles) {
                    return array.some(roles, function(role) {
                        return array.indexOf(ConfigModel.config.roles, role) > -1;
                    });
                }
                return true;
            }
        });

        var AccessModel = declare(null, {
            // summary:
            //     Model for access rights.

            // access: Object
            //      Holds access settings
            access: null,

            constructor: function(options) {
                declare.safeMixin(this, options);
                this._configureAccess();
            },

            isEnabled: function(intent) {
                // Summary:
                //      Check if specified intent is enabled for the current user
                var access = this._getAccessForIntent(this.access, intent);
                if (!access) {
                    return false;
                }

                return access.isEnabled();
            },

            isAllowed: function(intent) {
                // summary:
                //      Check if specified intent is allowed for the current user
                var access = this._getAccessForIntent(this.access, intent);
                if (!access) {
                    return false;
                }
                return access.isAllowed();
            },

            _configureAccess: function() {
                // Summary:
                //      Configures default access for each intent

                this.access = this._createDefaultAccess(config.intents);
            },

            _createDefaultAccess: function (intents) {
                var access = {};

                for (var i in intents) {
                    var intent = intents[i];
                    if (intent instanceof Object) {
                        access[i] = this._createDefaultAccess(intent);
                    }
                    else {
                        access[i] = new AccessItem({intent: intent});
                    }
                }
                return access;
            },

            _getAccessForIntent: function(accessSet, intent) {
                if (!accessSet) {
                    return null;
                }
                for (var a in accessSet) {
                    var access = accessSet[a];
                    if (!access.intent) {
                        var child = this._getAccessForIntent(access, intent);
                        if (child) {
                            return child;
                        }
                    }
                    else {
                        if (access.intent === intent) {
                            return access;
                        }
                    }
                }
                return null;
            }
        });
        var accessModel = new AccessModel();
        return accessModel;
    });